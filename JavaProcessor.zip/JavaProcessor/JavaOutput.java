//Program to calculate sum of two numbers.
public class TestProgram
{
    public static void main(String[]args)
    {
        int n1,n2;
        n1=5;
        n2=10;
        int answer=0;
        answer=n1+n2;
        System.out.println(answer);
    }
}

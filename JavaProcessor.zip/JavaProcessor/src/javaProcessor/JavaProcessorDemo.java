
/*Jason Holt and Melody Snitker, Group 8
COSC 3420.501
Project 4
Due 4/8/2015
Displays JavaProcessor GUI
*/


package javaProcessor;

public class JavaProcessorDemo {


	public static void main(String[] args) {
		JavaProcessor myProcessor = new JavaProcessor();
		myProcessor.setVisible(true);

	}

}

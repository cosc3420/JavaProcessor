package javaProcessor;

public class JavaProcessorDemo {


	public static void main(String[] args) {
		JavaProcessor myProcessor = new JavaProcessor();
		myProcessor.setVisible(true);

	}

}
